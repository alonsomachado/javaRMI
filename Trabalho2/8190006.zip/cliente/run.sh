javac *.java
java -Djava.security.policy=policy.all Client servidor
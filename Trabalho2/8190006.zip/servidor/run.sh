javac *.java
java -Djava.security.policy=policy.all ServidorImpl servidor